package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.graphics.drawable.*;
import java.util.*;

public class LevelsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_levels);

        Button btnBack = findViewById(R.id.btnBackFromLevels);
        GridView gridView = findViewById(R.id.levelsGrid);
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LevelsActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        });

        SharedPreferences prefs = getSharedPreferences("MathPrefs", MODE_PRIVATE);
        final int currentLevel = prefs.getInt("currentLevel", 1);

        ArrayList<String> levelsList = new ArrayList<>();
        for (int i = 1; i <= 20; i++) {
            levelsList.add(String.valueOf(i));
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, 0, levelsList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                Button btn = new Button(getContext());
                final int levelNum = position + 1;
                
                btn.setText(String.valueOf(levelNum));
                btn.setTextSize(14); 
                btn.setSingleLine(true);
                btn.setGravity(Gravity.CENTER);
                btn.setPadding(0, 0, 0, 0);

                GradientDrawable shape = new GradientDrawable();
                shape.setShape(GradientDrawable.RECTANGLE);
                shape.setCornerRadius(18f);

                if (levelNum <= currentLevel) {
                    shape.setColor(0xFF00D1B2);
                    RippleDrawable ripple = new RippleDrawable(
                        android.content.res.ColorStateList.valueOf(0x40000000),
                        shape,
                        null
                    );
                    btn.setBackground(ripple);
                    btn.setTextColor(0xFF000000);
                    btn.setAlpha(1.0f);
                    btn.setEnabled(true);
                } else {
                    shape.setColor(0xFF2D2D2E);
                    btn.setBackground(shape);
                    btn.setTextColor(0xFF555555);
                    btn.setAlpha(0.4f);
                    btn.setEnabled(false);
                }

                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(LevelsActivity.this, SecondActivity.class);
                        intent.putExtra("levelNumber", levelNum);
                        startActivity(intent);
                        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                    }
                });

                int screenWidth = getResources().getDisplayMetrics().widthPixels;
                float density = getResources().getDisplayMetrics().density;
                int totalSpacing = (int) (18 * density);
                int columnWidth = (screenWidth - totalSpacing) / 6;

                btn.setLayoutParams(new GridView.LayoutParams(columnWidth, columnWidth));
                
                return btn;
            }
        };

        gridView.setAdapter(adapter);
    }
}