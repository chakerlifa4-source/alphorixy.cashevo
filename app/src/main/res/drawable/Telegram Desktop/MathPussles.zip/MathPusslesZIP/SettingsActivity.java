package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class SettingsActivity extends Activity {

    // تعريف المتغيرات لحفظ الحالات (مؤقتاً)
    private boolean isDarkMode = true;
    private boolean isSoundOn = true;
    private boolean isLoggedIn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_layout);

        final Button btnBack = findViewById(R.id.btnBackSettings);
        final Button btnTheme = findViewById(R.id.btnThemeToggle);
        final Button btnSound = findViewById(R.id.btnToggleSound);
        final Button btnLogin = findViewById(R.id.btnLogin);
        final Button btnLogout = findViewById(R.id.btnLogout);
        final Button btnDelete = findViewById(R.id.btnDeleteAccount);

        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        });
        
        btnTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isDarkMode) {
                    btnTheme.setText("الوضع الليلي 🌙 ⇄");
                    Toast.makeText(SettingsActivity.this, "تم تفعيل الوضع النهاري", Toast.LENGTH_SHORT).show();
                } else {
                    btnTheme.setText("الوضع النهاري ☀ ⇄");
                    Toast.makeText(SettingsActivity.this, "تم تفعيل الوضع الليلي", Toast.LENGTH_SHORT).show();
                }
                isDarkMode = !isDarkMode;
            }
        });

        // برمجة زر الصوت
        btnSound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSoundOn) {
                    btnSound.setText("تشغيل الأصوات 🔇");
                } else {
                    btnSound.setText("كتم الأصوات 🔊");
                }
                isSoundOn = !isSoundOn;
            }
        });

        // برمجة زر تسجيل الدخول (تجريبي)
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isLoggedIn = true;
                updateAccountButtons(btnLogin, btnLogout, btnDelete);
                Toast.makeText(SettingsActivity.this, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show();
            }
        });

        // برمجة زر تسجيل الخروج
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isLoggedIn = false;
                updateAccountButtons(btnLogin, btnLogout, btnDelete);
            }
        });
    }

    // دالة لتحديث ظهور الأزرار بناءً على حالة الدخول
    private void updateAccountButtons(Button login, Button logout, Button delete) {
        if (isLoggedIn) {
            login.setVisibility(View.GONE);
            logout.setVisibility(View.VISIBLE);
            delete.setVisibility(View.VISIBLE);
        } else {
            login.setVisibility(View.VISIBLE);
            logout.setVisibility(View.GONE);
            delete.setVisibility(View.GONE);
        }
    }
}