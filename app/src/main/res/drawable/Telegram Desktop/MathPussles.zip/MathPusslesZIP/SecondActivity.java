package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class SecondActivity extends Activity {

    String[] questions = {
        "2 + 2 × 2 = ?",
        "4, 8, 16, ?", 
        "A=20, B=5 C=2 \n A - B × C = ?", 
        "3, 6, 9, ?",
        "100 + 50 ÷ 2 = ?",
        "□=4, □□=8, □□□=12, □□□□=?"
    };

    String[] answers = {"6", "32", "10", "12", "125", "16"};
    
    String[] hints = {
        "الأولوية للضرب قبل الجمع",
        "اضرب الرقم الأخير في 2", 
        "ابدأ بعملية الضرب أولاً ثم الجمع", 
        "النمط هو إضافة رقم 3 في كل مرة",
        "القسمة لها الأولوية، احسب 50 ÷ 2 أولاً",
        "أحسب ضلوع كل المربعات"
    };
    
    int currentLevel = 0; 

    TextView txtQuestion;
    EditText inputAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.second_layout);

        txtQuestion = findViewById(R.id.txtQuestion); 
        inputAnswer = findViewById(R.id.inputAnswer);
        Button btnCheck = findViewById(R.id.btnCheck);
        Button btnBack = findViewById(R.id.btnBack); 

        int levelToStart = getIntent().getIntExtra("levelNumber", 1);
        currentLevel = levelToStart - 1;

        if (currentLevel < 0) currentLevel = 0;
        if (currentLevel >= questions.length) currentLevel = questions.length - 1;

        updateQuestion();

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userChoice = inputAnswer.getText().toString().trim();
                
                if (userChoice.isEmpty()) {
                    Toast.makeText(SecondActivity.this, "أدخل رقماً أولاً!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (userChoice.equals(answers[currentLevel])) {
                    showSuccessDialog(); 
                } else {
                    Toast.makeText(SecondActivity.this, "إجابة خاطئة، حاول ثانية", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button btnHint = findViewById(R.id.btnHint);
        btnHint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SecondActivity.this, "تلميح: " + hints[currentLevel], Toast.LENGTH_LONG).show();
            }
        });
        
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        });
    }
    

    public void updateQuestion() {
        if (currentLevel < questions.length) {
            txtQuestion.setText(questions[currentLevel]);
            inputAnswer.setText(""); 
        } else {
            Toast.makeText(this, "رائع! أنهيت كل الألغاز", Toast.LENGTH_LONG).show();
            finish(); 
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        }
    }

    public void showSuccessDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View layout = getLayoutInflater().inflate(R.layout.dialog_success, null);
        builder.setView(layout);
        builder.setCancelable(false); 

        final AlertDialog dialog = builder.create();

        Button btnNext = layout.findViewById(R.id.btnNext);
        Button btnAgain = layout.findViewById(R.id.btnAgain);
        Button btnMenu = layout.findViewById(R.id.btnMenu);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentLevel++;
                
                SharedPreferences prefs = getSharedPreferences("MathPrefs", MODE_PRIVATE);
                int savedLevel = prefs.getInt("currentLevel", 1);
                
                if ((currentLevel + 1) > savedLevel) {
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("currentLevel", currentLevel + 1); 
                    editor.apply();
                }
                
                updateQuestion(); 
                dialog.dismiss(); 
            }
        });

        btnAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputAnswer.setText(""); 
                dialog.dismiss(); 
            }
        });

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                finish();
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            }
        });
        
        Button btnSettingsDialog = layout.findViewById(R.id.btnSettingsDialog);
        btnSettingsDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        dialog.show();
    }
}