package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextView btnClose = findViewById(R.id.btnCloseLogin);
        LinearLayout btnGoogle = findViewById(R.id.btnGoogleLogin);
        Button btnEmail = findViewById(R.id.btnEmailLogin);

        // برمجة زر X للمتابعة كضيف (بدون حساب)
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                skipToMain();
            }
        });

        // زر البريد الإلكتروني (مثال)
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                skipToMain();
            }
        });
    }

    private void skipToMain() {
        // حفظ أن المستخدم دخل اللعبة لكي لا تظهر الواجهة مرة أخرى
        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        prefs.edit().putBoolean("isFirstRun", false).apply();

        // الانتقال للواجهة الرئيسية
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
        // تطبيق تأثير الانتقال البطيء الذي أنشأناه سابقاً
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}