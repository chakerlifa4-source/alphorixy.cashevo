package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.content.*;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        final ImageView logo = findViewById(R.id.splashLogo);
        final LinearLayout textContainer = findViewById(R.id.textContainer);
        final ProgressBar loader = findViewById(R.id.splashLoader);

        loader.setMax(100);

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(1000);
        
        final AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setDuration(1000);

        logo.startAnimation(fadeIn);

        new CountDownTimer(6000, 30) {
            @Override
            public void onTick(long millisUntilFinished) {
                int progress = (int) ((6000 - millisUntilFinished) / 60);
                loader.setProgress(progress);
            }

            @Override
            public void onFinish() {
                loader.setProgress(100);
            }
        }.start();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                logo.startAnimation(fadeOut);
                logo.setVisibility(View.INVISIBLE);
                
                textContainer.setVisibility(View.VISIBLE);
                AlphaAnimation textFadeIn = new AlphaAnimation(0.0f, 1.0f);
                textFadeIn.setDuration(1000);
                textContainer.startAnimation(textFadeIn);
            }
        }, 3000);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                boolean isFirstRun = prefs.getBoolean("isFirstRun", true);

                Intent intent;
                if (isFirstRun) {
                    intent = new Intent(SplashActivity.this, LoginActivity.class);
                } else {
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                }
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        }, 6000);
    }
}